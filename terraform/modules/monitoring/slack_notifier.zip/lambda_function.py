import json, urllib.request, os

def handler(event, context):
    webhook = os.environ['SLACK_WEBHOOK_URL']
    for record in event.get('Records', []):
        sns_msg = json.loads(record['Sns']['Message'])
        alarm   = sns_msg.get('AlarmName', 'Unknown')
        state   = sns_msg.get('NewStateValue', 'UNKNOWN')
        reason  = sns_msg.get('NewStateReason', '')
        color   = '#FF0000' if state == 'ALARM' else '#00FF00'
        payload = {
            'attachments': [{
                'color': color,
                'title': f'CloudWatch Alarm: {alarm}',
                'text': f'State: *{state}*\nReason: {reason}',
                'footer': 'AWS CloudWatch'
            }]
        }
        req = urllib.request.Request(
            webhook,
            data=json.dumps(payload).encode(),
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        urllib.request.urlopen(req)
    return {'statusCode': 200}
